import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Guardar mi PDF");
            frame.setSize(400, 200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JTextArea texto = new JTextArea();
            JButton botonGuardado = new JButton("Guardar a PDF");

            botonGuardado.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String contenido = texto.getText();
                    guardarComoPDF(contenido);
                }
            });

            JPanel panel = new JPanel();
            panel.add(texto);
            panel.add(botonGuardado);

            frame.add(panel);
            frame.setVisible(true);
        });
    }

    private static void guardarComoPDF(String contenido) {
        JFileChooser selectorArchivos = new JFileChooser();
        int resultado = selectorArchivos.showSaveDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            String rutaArchivo = selectorArchivos.getSelectedFile().getAbsolutePath() + ".pdf";

            try (PdfWriter lector = new PdfWriter(rutaArchivo);
                 PdfDocument pdf = new PdfDocument(lector);
                 Document documento = new Document(pdf)) {

                documento.add(new Paragraph(contenido));
                System.out.println("PDF guardado exitosamente en: " + rutaArchivo);

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Error al guardar el PDF: " + e.getMessage());
            }
        }
    }
}
